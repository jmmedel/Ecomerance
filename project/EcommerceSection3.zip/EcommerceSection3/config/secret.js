module.exports = {

  database: 'mongodb://root:abc123@ds037095.mongolab.com:37095/ecommerce',
  port: 3000,
  secretKey: "Arash@$@!#@"
}
